﻿namespace Antigaspi.Domain;

public class Class1
{

}
