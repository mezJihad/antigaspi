namespace Antigaspi.Domain.Enums;

public enum UserRole
{
    CUSTOMER,
    SELLER,
    ADMIN
}
