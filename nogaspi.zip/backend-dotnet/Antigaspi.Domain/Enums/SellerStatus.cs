namespace Antigaspi.Domain.Enums;

public enum SellerStatus
{
    PENDING,
    APPROVED,
    REJECTED,
    SUSPENDED
}
