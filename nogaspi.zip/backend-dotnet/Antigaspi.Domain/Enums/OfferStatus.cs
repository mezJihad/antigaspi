namespace Antigaspi.Domain.Enums;

public enum OfferStatus
{
    DRAFT,
    PENDING_VALIDATION,
    PUBLISHED,
    REJECTED,
    CANCELED,
    EXPIRED
}
