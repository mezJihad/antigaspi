﻿namespace Antigaspi.Infrastructure;

public class Class1
{

}
