﻿namespace Antigaspi.Application;

public class Class1
{

}
